function GetRadorInput(xAxis, yAxis) {
    var schema = '<table id="freq" border="0" cellspacing="0" cellpadding="0"><tr nowrap bgcolor="#CCCCFF"><th colspan="9" class="hdr">Data</th>' +
		'</tr>';
    var legend = '';
    var Column = '';

    for (var index = 0; index < xAxis.length; index++) {
        Column += '<tr nowrap>'
        
         if (index % 2 == 0) {

        if (index == 0) {
            legend += '<tr nowrap><th class="freq">ULB</th>';
            for (var i = 0; i < yAxis.length; i++) {
                legend +='<th class="freq">'+ yAxis[i].name+'</th>'
            }
            legend += '</tr>'; 
        }

            Column += '<td class="dir">' + xAxis[index] + '</td>';
            for (var i = 0; i < yAxis.length; i++) {
                var dataArr = yAxis[i].data;
                Column += '<td class="data">' + dataArr[index] + '</td>';

            }
        }
        else {
            Column += '<td class="dir">' + xAxis[index] + '</td>';
            for (var i = 0; i < yAxis.length; i++) {
                var dataArr = yAxis[i].data;                
                Column += '<td class="data">' + dataArr[index] + '</td>';
            }
        }


        Column += '</tr>';
    }
    schema += legend + Column + '</table>';

    $("#radorTable")[0].innerHTML = schema;

    //Hide show legend
    $("#stackChartContainer").find(".bottomlegends").find("#legend1").hide();
    $("#stackChartContainer").find(".bottomlegends").find("#legend2").hide();
    $("#stackChartContainer").find(".bottomlegends").find("#legend3").hide();
    $("#stackChartContainer").find(".bottomlegends").find("#legend4").hide();
    $("#stackChartContainer").find(".bottomlegends").find("#legend5").hide();
    $("#stackChartContainer").find(".bottomlegends").find("#legend6").hide();
    $("#stackChartContainer").find(".bottomlegends").find("#legend7").hide();
    for (var i = 1; i <= yAxis.length; i++) {
        $("#stackChartContainer").find(".bottomlegends").find("#legend" + i).show();
        $("#stackChartContainer").find(".bottomlegends").find("#legend" + i).find(".legend" + i).css("background", yAxis[i - 1].color);
        $("#stackChartContainer").find(".bottomlegends").find("#legend" + i).find("#legendvalue" + i).text(yAxis[i - 1].name);
    }
   
   }


   function GenrateRadorChart(chartname) {
       $('#pieDetails').hide();
       $(".chart-expand").css("width","800");
       $(".chart-expand").css("height","390");
       $('#' + chartname).show();
       $('#chartContainer').highcharts({
           data: {
               table: 'freq',
               startRow: 1,
               endRow: 130,
               endColumn: 10,
           },
           colors: ["#c9e726", "#666666", "#1aadce", "#f28f43", "#2f7ed8", "#492970", "#7798BF",
      "#55BF3B", "#DF5353", "#7798BF", "#aaeeee"],
           chart: {
               
               polar: true,
               type: 'column',
               width: '400',
               height: '330',
               margin:[50,80,50,100]
             
           },
            credits:
            {
                enabled: false
            },

           title: {
               text: ''
           },

           subtitle: {
               text: ''
           },

           pane: {
               size: '100%'
           },

           legend: {
               enabled: false,
               reversed: true,
               align: 'right',
               verticalAlign: 'top',
               y: 100,
               layout: 'vertical'
           },

           xAxis: {
               tickmarkPlacement: 'between',
               
               
       },

       yAxis: {
           min: 0,
           endOnTick: false,
           showLastLabel: true,
           pointPlacement: 'between',           
           title: {
               text: ''
           },
           labels: {
               formatter: function () {
                   return this.value + '';
               }
           }
       },

       tooltip: {
           valueSuffix: ''
       },

       plotOptions: {
           series: {
               stacking: 'normal',
               shadow: false,
               groupPadding: 0,
               point: {
                   events: {
                       click: function (e) {
                           LoadRadarCharTable(e);
                       }
                   }
               }
           }
       }
   });
   }

   function LoadRadarCharTable(e) {
       
//       alert(window.localStorage.getItem("EType"));
//       alert(window.localStorage.getItem("EULBname"));
      //      alert(window.localStorage.getItem("EULBtype"));



       var legendArr = e.point.series.name.split('%');
       if (window.localStorage.getItem("EType") == 'designed') {
           GetDesignedDrawnQuantity($.trim(legendArr[0]), window.localStorage.getItem("EULBtype"), window.localStorage.getItem("EULBname"), e.point.name);
       }
       else if (window.localStorage.getItem("EType") == 'cleaning') {
           GetCleaningStatus($.trim(legendArr[0]), window.localStorage.getItem("EULBtype"), window.localStorage.getItem("EULBname"), e.point.name);
       }
       else if (window.localStorage.getItem("EType") == 'issues') {
           GetIssuesStatus($.trim(legendArr[0]), window.localStorage.getItem("EULBtype"), window.localStorage.getItem("EULBname"), e.point.name);
       }

   }

   function GetDesignedDrawnQuantity(legend, type, name,UlbName) {
       var DesignedDrawnDetails = new Array();
       var columndetails = new Array();
       var details = null;
       if (window.localStorage.getItem("EULBtype") == 'Corporations') {
           $(ulbDetails).find('Corporation[Name=' + UlbName + ']').find('SourceData Source').each(function () {
               if ($(this).attr("Utilization") == legend) {
                   details = new Object;
                   details.Name = $(this).attr("Name");
                   details.Column1 = $(this).attr("DesignedQty");
                   details.Column2 = $(this).attr("Quantity");
                   DesignedDrawnDetails.push(details);
               }
           });
       }
       else {
           $(ulbDetails).find('Municipality[Name=' + UlbName + ']').find('SourceData Source').each(function () {
               if ($(this).attr("Utilization") == legend) {
                   details = new Object;
                   details.Name = $(this).attr("Name");
                   details.Column1 = $(this).attr("DesignedQty");
                   details.Column2 = $(this).attr("Quantity");
                   DesignedDrawnDetails.push(details);
               }
           });
       }
       columndetails.push('Source');
       columndetails.push('Designed Qty/MLD');
       columndetails.push('Drawn Qty/MLD');
       GenerateTable(DesignedDrawnDetails, columndetails,UlbName);
   }

   function GetCleaningStatus(legend, type, name, UlbName) {
       
       var ScheduledDetails = new Array();
       var columndetails = new Array();
       var details = null;
       var filter = (legend.toLowerCase() == 'scheduled') ? 'ScheduledDate' : 'CleanedDate';
       if (type != null) {
           $(ulbDetails).find('Corporation[Name=' + UlbName + ']').find('TankData Tank').each(function () {
               if ($(this).attr(filter) != '-') {
                   details = new Object;
                   details.Name = $(this).attr("Name");
                   details.Column1 = $(this).attr("ScheduledDate");
                   details.Column2 = $(this).attr("CleanedDate");
                   ScheduledDetails.push(details);
               }
           });
       }
       else {
           $(ulbDetails).find('Municipality[Name=' + UlbName + ']').find('TankData Tank').each(function () {
               if ($(this).attr(filter) == legend) {
                   details = new Object;
                   details.Name = $(this).attr("Name");
                   details.Column1 = $(this).attr("ScheduledDate");
                   details.Column2 = $(this).attr("CleanedDate");
                   ScheduledDetails.push(details);
               }
           });
       }
       columndetails.push('Name');
       columndetails.push('Scheduled');
       columndetails.push('Cleaned');
       GenerateTable(ScheduledDetails, columndetails,UlbName);
   }


   function GetIssuesStatus(legend, type, name, UlbName) {
       
       var ScheduledDetails = new Array();
       var columndetails = new Array();
       var details = null;
       var filter = legend;
       if (window.localStorage.getItem("EULBtype") == 'Corporations') {
       
           $(lpcdDetails).find('Corporation[Name=' + UlbName + ']').find('Dates Data').each(function () {
           var cObject=this;
                details = new Object;
                details.Name = $(this).attr("Date");
               
                $(this).find('Reasons').find('TReason').each(function()
                  {
                 /* if($(this).attr('Reason').indexOf(filter)!=-1)
                  {     */            
                   
                   details.Column1 = $(this).attr('Reason');

                   $(cObject).find('Actions').find('Action').each(function()
                  {
                  
                   details.Column2 = $(this).attr('Content');
                  
                  
                  });

                 /* }*/
                  });
                if((details.Column1!='' && details.Column1!=null) || (details.Column2!='' && details.Column2!=null))
                {
                	   ScheduledDetails.push(details);
                }

               
           });
       }
       else {
           $(lpcdDetails).find('Municipality[Name=' + UlbName + ']').find('Dates MDate').each(function () {
              details = new Object;
                details.Name = $(this).attr("Date");
                var cObject=this;
              
                  $(this).find('Reasons').find('TReason').each(function()
                  {
                 /* if($(this).attr('Reason').indexOf(filter)!=-1)
                  {   */              
                   
                   details.Column1 = $(this).attr('Reason');

                   $(cObject).find('Actions').find('Action').each(function()
                  {
                  
                   details.Column2 = $(this).attr('Content');
                  
                  
                  });

                 /* }*/
                  });

                   
				

               
                if((details.Column1!='' && details.Column1!=null) || (details.Column2!='' && details.Column2!=null))
                {
                    ScheduledDetails.push(details);
                }

           });
       }
       columndetails.push('Date');
       columndetails.push('Reason');
       columndetails.push('Action');
       GenerateTable(ScheduledDetails, columndetails,UlbName);
   }



   function GenerateTable(data, ColumnDetails,UlbName) {
       var Sourcestruc = '<div style=width:100%;text-align:center;margin:5px><span>'+UlbName+'</span></div> <table><thead>';
       for (var i = 0; i < ColumnDetails.length; i++) {
           Sourcestruc += "<td style='text-align: center;'><span class='design_mld'>" + ColumnDetails[i] +"</span></td>";
       }
       Sourcestruc += '</thead>';
       var total = 0;
       for (var j = 0; j < data.length; j++) {
           var col1='';
           var col2='';
           if(data[j].Column1.length>20)
           {
               col1=data[j].Column1.substring(0,20)+'...';
              
}
           else
           {
               col1=data[j].Column1;
}
            if(data[j].Column2.length>20)
           {
               col2=data[j].Column2.substring(0,20)+'...';
               
}
           else
           {
               col2=data[j].Column2;
}
           
           Sourcestruc += "<tr><td style='text-indent: 0%;'>" + data[j].Name + "</td><td style='text-align: center;'><label class='tooltip' title='" + data[j].Column1+ "'>"+col1 +"</label> </td><td style='text-align: center;'><label class='tooltip' title='" + data[j].Column2+ "'>"+col2+"</td></tr>";
       }
       Sourcestruc += '<table>';

       $('#pieDetails')[0].innerHTML = Sourcestruc;
       $('.tooltip').tooltip();
       $('#pieDetails').show();
 		
	   }